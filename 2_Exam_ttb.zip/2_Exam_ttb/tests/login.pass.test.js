// @ts-check
import { test, expect } from '@playwright/test';



test('login success', async ({ page }) => {
  await page.goto('http://the-internet.herokuapp.com/login');
  await page.locator('#username').fill('tomsmith');
  await page.locator('#password').fill('SuperSecretPassword!');
  await page.getByRole('button', { name: ' Login' }).click();

  const loginsuccessmsg  =  await page.locator('#flash').textContent();
  console.log("loginsuccessmsg : ",loginsuccessmsg?.replace(/(\r\n|\n|\r)/gm, ' '));
  expect(loginsuccessmsg?.replace(/(\r\n|\n|\r)/gm, ' ')).toEqual('             You logged into a secure area!             ×           ');


  await page.locator('//div[@class="example"]/a').click();

  const logoutsuccessmsg  =  await page.locator('#flash').textContent();
  console.log("logoutsuccessmsg : ",logoutsuccessmsg?.replace(/(\r\n|\n|\r)/gm, ' '));
  expect(logoutsuccessmsg?.replace(/(\r\n|\n|\r)/gm, ' ')).toEqual('             You logged out of the secure area!             ×           ');
});

test('login fail - password incorrect', async ({ page }) => {
  await page.goto('http://the-internet.herokuapp.com/login');
  await page.locator('#username').fill('tomsmith');
  await page.locator('#password').fill('Password!');
  await page.getByRole('button', { name: ' Login' }).click();

  const loginfail_password  =  await page.locator('#flash').textContent();
  console.log("loginfail password incorrect : ",loginfail_password?.replace(/(\r\n|\n|\r)/gm, ' '));
  expect(loginfail_password?.replace(/(\r\n|\n|\r)/gm, ' ')).toEqual('             Your password is invalid!             ×           ');
});


test('login fail - username not found', async ({ page }) => {
  await page.goto('http://the-internet.herokuapp.com/login');
  await page.locator('#username').fill('tomholland');
  await page.locator('#password').fill('Password!');
  await page.getByRole('button', { name: ' Login' }).click();

  const loginfail_username  =  await page.locator('#flash').textContent();
  console.log("loginfail username incorrect : ",loginfail_username?.replace(/(\r\n|\n|\r)/gm, ' '));
  expect(loginfail_username?.replace(/(\r\n|\n|\r)/gm, ' ')).toEqual('             Your username is invalid!             ×           ');
});

