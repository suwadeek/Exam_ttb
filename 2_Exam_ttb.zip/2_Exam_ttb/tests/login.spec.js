// import test, { expect, Test } from "@playwright/test";
import { expect} from "@playwright/test";
import { test } from "../pages/base.ts";
// import { LoinPage } from "../pages/login.page";
import { LoginPage } from "../pages/login.page.js";
// import { validUsers } from "../utill/index.js";
// import validUsers from "../utill/index.js";


test.beforeEach(async({ loginPage }) => {
    await loginPage.goto();
})

// test('Login', async ({ page }) => {
test('Login', async ({ loginPage }) => {
    // const loginPage = new LoginPage(page);
    // await loginPage.goto();

    await loginPage.fillUserPassword('testuser','password');
    expect(await loginPage.getUsername()).toBe('testuser');
    expect(await loginPage.getPassword()).toBe('password');

});

test('Blank username', async ({ loginPage }) => {
    // const loginPage = new LoginPage(page);
    // await loginPage.goto();

    await loginPage.fillUserPassword(' ','password');
    await loginPage.clicklogin();

    const message = loginPage.getErrorMessage();
    console.log('Error Message : ', await message);
    expect(await message).toContain('Epic sadface: Username and password do not match any user in this service');

    const validURL = loginPage.isValidURL();
    expect(await validURL).toBe(true);
});

test('Blank username password', async ({ loginPage }) => {
    // const loginPage = new LoginPage(page);
    // await loginPage.goto();

    await loginPage.fillUserPassword(' ',' ');
    await loginPage.clicklogin();

    const message = loginPage.getErrorMessage();
    console.log('Error Message : ', await message);
    expect(await message).toContain('Epic sadface: Username and password do not match any user in this service');

    const validURL = loginPage.isValidURL();
    expect(await validURL).toBe(true);
});



const module = require('../utill/index.js');
module.validUsers.forEach(({ username,password }) => {
    test('Valid User '+ username, async ({ loginPage }) => {
        console.log('username : ' , username);
        console.log('username : ' + username);
        await loginPage.fillUserPassword(username,password);
        await loginPage.clicklogin();
        
        const validURL = loginPage.isValidURL();
        expect(await validURL).toBe(false);
    });

});

module.invalidUser.forEach(({ username,password }) => {
    // test.only('Invalid User '+ username, async ({ loginPage }) => {
    test('Invalid User '+ username, async ({ loginPage }) => {
        console.log('username : ' , username);
        console.log('username : ' + username);
        await loginPage.fillUserPassword(username,password);
        await loginPage.clicklogin();

        const message = loginPage.getErrorMessage();
        console.log('Error Message : ', await message);
        expect(await message).toContain('Epic sadface');

        const validURL = loginPage.isValidURL();
        expect(await validURL).toBe(true);
    });

});


const xlsx = require('xlsx');
const workbook = xlsx.readFile('tests/utill/sample.xlsx');

const sheetName = workbook.SheetNames[0]; // Get the name of the first sheet
const worksheet = workbook.Sheets[sheetName];

const data = xlsx.utils.sheet_to_json(worksheet);

// Example: Using data to drive tests
for (const rowData of data) {
    console.log('Data : ' + rowData.No);

    test(`Test with data: ` + rowData.No, async ({ page }) => {
                expect(rowData.City).toContain('Boston');
                
            // await page.fill('#username', rowData.City);
            // await page.fill('#password', rowData.password);
            // await page.click('#loginButton');
            // Add assertions based on rowData.expectedResult
        
    });

    break;
}

