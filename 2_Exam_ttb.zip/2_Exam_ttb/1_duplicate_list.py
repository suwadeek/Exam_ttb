list_a = [1,2,3,5,6,8,9]
list_b = [3,2,1,5,6,0]
list_dup = []

for a in list_a:
    for b in list_b:
        if a == b:
            list_dup.append(b)
            break

print("Dupilcate List : " ,list_dup)