list_alphabet = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
list_tryme = ['T','R','Y','M','E']
list_simple_cipher_encrypt = []

count = 0
index_tryme = 0
index_alphabet = 0
while count < 100:

    if(list_tryme[index_tryme] == list_alphabet[index_alphabet]):
        list_simple_cipher_encrypt.append(list_alphabet[index_alphabet-2])
        index_tryme +=1
        index_alphabet = -1

    index_alphabet +=1
    count += 1

    if(index_tryme == 5):
        break

print("List Alphabet : ", list_alphabet)
print("List TRYME : " , list_tryme)
print("List Simple Chiper Decrypt TRYME : ", list_simple_cipher_encrypt)